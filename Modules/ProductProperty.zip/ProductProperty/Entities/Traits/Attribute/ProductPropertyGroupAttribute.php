<?php

namespace Modules\ProductProperty\Entities\Traits\Attribute;

trait ProductPropertyGroupAttribute
{
}
