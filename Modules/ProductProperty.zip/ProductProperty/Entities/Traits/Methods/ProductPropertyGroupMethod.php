<?php


namespace Modules\ProductProperty\Entities\Traits\Methods;


trait ProductPropertyGroupMethod
{
}