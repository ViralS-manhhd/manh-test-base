<?php


namespace Modules\ProductProperty\Entities\Traits\Methods;


trait ProductPropertyPriceMethod
{
}