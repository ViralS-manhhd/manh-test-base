<?php

namespace Modules\ProductProperty\Entities\Traits\Relationship;

trait ProductPropertyPriceRelationship
{
}
