<?php

return [
    'name' => 'ProductProperty'
];
