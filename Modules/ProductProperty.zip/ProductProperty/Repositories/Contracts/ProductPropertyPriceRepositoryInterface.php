<?php

namespace Modules\ProductProperty\Repositories\Contracts;

use Modules\Core\Repositories\Contracts\BaseRepositoryInterface;

interface ProductPropertyPriceRepositoryInterface extends BaseRepositoryInterface
{
}
