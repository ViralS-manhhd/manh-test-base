<?php

namespace Modules\ProductProperty\Repositories\Contracts;

use Modules\Core\Repositories\Contracts\BaseRepositoryInterface;

interface ProductPropertyGroupRepositoryInterface extends BaseRepositoryInterface
{
}
